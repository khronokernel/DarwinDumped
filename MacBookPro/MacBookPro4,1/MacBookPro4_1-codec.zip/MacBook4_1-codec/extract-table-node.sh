#!/bin/bash

cat << EOF

Node are Number into ()
                     (xx) at end of line is pointer to "Node (xx)"
                     only follow 1 time (xx) at end of line
                     NodeID is (xx) (xx) (xx) scheme

EOF

egrep "^Node|^[[:blank:]]{1,10}[[:digit:]]|Pin Default" "$1" | sed \
	-e "s/\].*:/]/" \
	-e "s/^\(Node \)\([[:digit:]]\{1,\}\)\(.*\)/\1(\2)\3/" \
	-e "s/^\([[:blank:]]\{1,\}\)\([[:digit:]\*]\{1,\}\)\(.*\)/\1(\2\) \3/" \
	| sed -e :a -e '$!N;s/\n\([[:blank:]].*\)/ => \1/;ta' -e 'P;D'
